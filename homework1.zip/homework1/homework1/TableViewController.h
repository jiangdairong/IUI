//
//  TableViewController.h
//  homework1
//
//  Created by dairong on 2014/3/1.
//  Copyright (c) 2014年 dairong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UITableViewController
@property(nonatomic,strong)NSArray *image;
@property(nonatomic,strong)NSArray *Title;
@property(nonatomic,strong)NSArray *Description;
@end
