//
//  StartViewController.h
//  homework1
//
//  Created by dairong on 2014/3/2.
//  Copyright (c) 2014年 dairong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StartViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *myImg;

@end
